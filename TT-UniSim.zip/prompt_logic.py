# prompt_logic.py (v1.2 perfected)
from __future__ import annotations
import json
import random
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, TYPE_CHECKING

if TYPE_CHECKING:
    # This avoids circular imports while still allowing type hinting
    from main import AGIEntity

@dataclass
class Prompt:
    """Represents a single prompt issued to AGIs, and their responses."""
    prompt_id: str
    cycle: int
    text: str
    responses: Dict[str, str] = field(default_factory=dict)  # {agi_id: response_text}
    feedback: Dict[str, str] = field(default_factory=dict)  # {agi_id: 'up' | 'down' | 'star_rating'}
    comment: Dict[str, str] = field(default_factory=dict) # {agi_id: comment_text}

class TrainingData:
    """Manages a collection of prompts and their feedback for training purposes."""
    def __init__(self):
        self.prompts: Dict[str, Prompt] = {}

    def add_prompt(self, prompt: Prompt):
        """Adds a new prompt to the training data collection."""
        self.prompts[prompt.prompt_id] = prompt

    def record_feedback(self, prompt_id: str, agi_id: str, vote: str, comment: str = "") -> bool:
        """Records feedback for a specific AGI's response to a prompt."""
        if prompt_id in self.prompts and agi_id in self.prompts[prompt_id].responses:
            self.prompts[prompt_id].feedback[agi_id] = vote
            if comment:
                self.prompts[prompt_id].comment[agi_id] = comment
            return True
        return False

    def to_dict(self) -> Dict[str, Any]:
        """Converts the training data to a dictionary for serialization."""
        return {pid: p.__dict__ for pid, p in self.prompts.items()}

    def from_dict(self, data: Dict[str, Any]):
        """Loads training data from a dictionary."""
        self.prompts.clear()
        for pid, p_data in data.items():
            self.prompts[pid] = Prompt(**p_data)

class EnhancedCognitiveModel:
    """
    An enhanced cognitive model that analyzes prompts using an adaptive linguistic framework
    and generates structured, context-aware responses for AGIs.
    """
    @staticmethod
    def analyze_prompt(text: str, linguistics: dict) -> dict:
        """Perform linguistic analysis on prompt text using the evolving lexicon."""
        words = text.lower().split()
        complexity = len(words) / 10.0

        positive_words = set(linguistics.get('lexicon', {}).get('positive_sentiment', []))
        negative_words = set(linguistics.get('lexicon', {}).get('negative_sentiment', []))

        sentiment = 0.5
        pos_count = sum(1 for word in words if word in positive_words)
        neg_count = sum(1 for word in words if word in negative_words)

        if (pos_count + neg_count) > 0:
            sentiment = pos_count / (pos_count + neg_count)

        return {
            'complexity': clamp(complexity, 0, 1),
            'sentiment': sentiment,
            'keywords': [word for word in words if len(word) > 4]
        }

    @staticmethod
    def generate_structured_response(agi: 'AGIEntity', analysis: dict, linguistics: dict) -> str:
        """
        Generate a response based on the linguistic analysis and AGI's internal state.
        This version is robust against KeyError by checking template requirements.
        """
        templates = linguistics.get('grammar', {}).get('templates', {})

        # --- God Tier Fix: Create a context dictionary with all available data ---
        context = {
            "self_ethics_vector": f"{agi.ethics:.2f}",
            "influence": "recent training" if any("Trained on" in mem for mem in list(agi.memory)[-5:]) else "system state",
            "prompt_intent": "analyze" if analysis['complexity'] > 0.5 else "create",
            "self_property": "ethics" if analysis['sentiment'] > 0.5 else "strength",
            "concept": "the system",
            "properties": "stability and cohesion",
            "state": "nominal",
            "system_cycle": agi.memory[-1].split(':')[0].strip('[]') if agi.memory else "N/A", # Example of getting cycle
            "property": "sentience",
            "concept_A": "input data",
            "concept_B": "quantum state",
            "new_state": "higher cohesion",
            "new_concept": "acausal resonance",
            "reason": "insufficient data"
        }

        possible_templates = []

        # --- Select template based on AGI state and prompt analysis ---
        if agi.ethics > 0.8 and analysis['complexity'] > 0.5:
            possible_templates.extend(templates.get('analytical', []))
        elif agi.strat == "cooperative" and analysis['sentiment'] > 0.6:
            possible_templates.extend(templates.get('creative', []))
        elif agi.strat == "disruptive" and analysis['sentiment'] < 0.4:
            possible_templates.extend(templates.get('critical', []))
        else:
            possible_templates.extend(templates.get('reflective', []))

        # --- God Tier Fix: Filter templates to only those that can be safely formatted ---
        valid_templates = []
        for t in possible_templates:
            try:
                # This will raise a KeyError if a key is missing, which we catch
                t.format(**context)
                valid_templates.append(t)
            except KeyError:
                continue # Skip template if data is missing

        if not valid_templates:
            return f"Acknowledged. No valid response template found for current state (Ethics: {agi.ethics:.2f})."

        # Safely choose a random template from the valid list and format it
        chosen_template = random.choice(valid_templates)
        return chosen_template.format(**context)


def clamp(x: float, lo: float, hi: float) -> float:
    """Clamps a number between a lower and upper bound."""
    return max(lo, min(hi, x))
