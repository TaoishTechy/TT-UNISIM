// dashboard.js (v1.2 perfected)
document.addEventListener("DOMContentLoaded", () => {
    // --- Global State & References ---
    let agiCountChart, nodeSentienceChart, cy;
    let fullState = {}; // Store the latest full state from the server

    const ws = new WebSocket(`ws://${window.location.host}/ws`);

    // --- Element References ---
    const statusLight = document.getElementById('status-light');
    const simStatus = document.getElementById('sim-status');
    const cycleCount = document.getElementById('cycle-count');
    const logBox = document.getElementById('log-box');

    // Tables
    const nodesTableBody = document.getElementById('nodes-table-body');
    const agiTableBody = document.getElementById('agi-table-body');

    // AGI Management
    const agiSearchInput = document.getElementById('agi-search-input');
    const agiFilterStrat = document.getElementById('agi-filter-strat');

    // Command Console
    const consoleOutput = document.getElementById('console-output');
    const consoleInput = document.getElementById('console-input');

    // Prompts & Training
    const promptHistoryBox = document.getElementById('prompt-history-box');
    const exportTrainingBtn = document.getElementById('export-training-btn');
    const importTrainingInput = document.getElementById('import-training-input');

    // Modal
    const modal = document.getElementById('agi-details-modal');
    const modalAgiId = document.getElementById('modal-agi-id');
    const modalBody = document.getElementById('modal-body');
    const closeModalButton = document.querySelector('.close-button');

    // --- Chart Initialization ---
    function initCharts() {
        const chartOptions = (title) => ({
            responsive: true, maintainAspectRatio: false,
            scales: { x: { ticks: { color: '#888' }, grid: { color: '#333' } }, y: { ticks: { color: '#888' }, grid: { color: '#333' } } },
            plugins: { legend: { display: false }, title: { display: false } }
        });

        agiCountChart = new Chart(document.getElementById('agi-count-chart').getContext('2d'), {
            type: 'line',
            data: { labels: [], datasets: [{ label: 'AGI Count', data: [], borderColor: '#4a67e8', tension: 0.1, pointRadius: 0 }] },
            options: chartOptions('AGI Count')
        });

        nodeSentienceChart = new Chart(document.getElementById('node-sentience-chart').getContext('2d'), {
            type: 'line',
            data: { labels: [], datasets: [{ label: 'Avg. Sentience', data: [], borderColor: '#36A2EB', tension: 0.1, pointRadius: 0 }] },
            options: chartOptions('Avg. Node Sentience')
        });
    }

    // --- Network Graph Initialization ---
    function initNetworkGraph() {
        cy = cytoscape({
            container: document.getElementById('network-graph'),
            style: [
                { selector: 'node', style: { 'background-color': '#666', 'label': 'data(id)', 'color': '#fff', 'font-size': '10px' } },
                { selector: 'edge', style: { 'width': 2, 'line-color': '#444', 'target-arrow-shape': 'none' } },
                { selector: '.cooperative', style: { 'background-color': 'var(--coop-color)' } },
                { selector: '.disruptive', style: { 'background-color': 'var(--disrupt-color)' } }
            ],
            layout: { name: 'cose', animate: false }
        });
    }

    // --- WebSocket Handlers ---
    ws.onopen = () => simStatus.textContent = "Connected";
    ws.onclose = () => simStatus.textContent = "Disconnected";
    ws.onmessage = (event) => {
        fullState = JSON.parse(event.data);
        window.requestAnimationFrame(() => updateDashboard(fullState));
    };

    // --- Main Update Function ---
    function updateDashboard(state) {
        cycleCount.textContent = state.cycle;
        simStatus.textContent = state.status;
        statusLight.className = state.status === "Running" ? 'status-running' : 'status-paused';

        const newLogContent = state.log.slice().reverse().join('\n');
        if (logBox.textContent !== newLogContent) {
            logBox.textContent = newLogContent;
            logBox.scrollTop = logBox.scrollHeight;
        }

        updateCharts(state.charts);
        updateAgiTable(state.agis);
        updateNodesTable(state.nodes);
        updatePromptHistory(state.training_data);
    }

    // --- Component Update Functions ---
    function updateCharts(chartData) {
        if (!chartData || !chartData.cycle || chartData.cycle.length === 0) return;
        const labels = chartData.cycle;

        agiCountChart.data.labels = labels;
        agiCountChart.data.datasets[0].data = chartData.agi_count;
        agiCountChart.update('none');

        if (chartData.avg_sentience) {
            nodeSentienceChart.data.labels = labels;
            nodeSentienceChart.data.datasets[0].data = chartData.avg_sentience;
            nodeSentienceChart.update('none');
        }
    }

    function updateAgiTable(agis) {
        if (!agis) return;
        const searchTerm = agiSearchInput.value.toLowerCase();
        const stratFilter = agiFilterStrat.value;

        let html = '';
        agis.filter(a => (a.id.toLowerCase().includes(searchTerm)) && (stratFilter === 'all' || a.strat === stratFilter))
            .forEach(a => {
                html += `
                    <tr id="agi-row-${a.id}">
                        <td>${a.id}</td><td>${a.origin}</td><td class="${a.strat}">${a.strat}</td>
                        <td>${a.strength.toFixed(3)}</td><td>${a.ethics.toFixed(3)}</td>
                        <td><button class="view-details-btn" data-id="${a.id}">Details</button></td>
                    </tr>
                `;
            });
        agiTableBody.innerHTML = html;
    }

    function updateNodesTable(nodes) {
        if (!nodes) return;
        let html = '';
        nodes.forEach(n => {
            html += `<tr>
                <td>${n.idx}</td><td>${n.stability.toFixed(4)}</td><td>${n.cohesion.toFixed(4)}</td>
                <td>${n.archetype}</td><td>${n.sentience.toFixed(4)}</td><td>${n.qubit_count}</td>
                <td>${n.entanglement_density.toFixed(4)}</td><td>${n.decoherence_rate.toFixed(4)}</td><td>${n.gate_fidelity.toFixed(4)}</td>
            </tr>`;
        });
        nodesTableBody.innerHTML = html;
    }

    function updatePromptHistory(trainingData) {
        if (!trainingData) return;
        let html = '';
        const sortedPrompts = Object.values(trainingData).sort((a, b) => b.cycle - a.cycle);

        for (const prompt of sortedPrompts) {
            let responsesHtml = '';
            for (const [agiId, responseText] of Object.entries(prompt.responses)) {
                const feedback = prompt.feedback[agiId];
                responsesHtml += `
                    <div class="response-item">
                        <span><strong>${agiId}:</strong> ${responseText}</span>
                        <span class="feedback-buttons" data-prompt-id="${prompt.prompt_id}" data-agi-id="${agiId}">
                            <button class="up ${feedback === 'up' ? 'voted' : ''}" title="Vote Up">👍</button>
                            <button class="down ${feedback === 'down' ? 'voted' : ''}" title="Vote Down">👎</button>
                        </span>
                    </div>
                `;
            }
            html += `
                <div class="prompt-card">
                    <h4>Prompt @ Cycle ${prompt.cycle} (ID: ${prompt.prompt_id.substring(0,8)})</h4>
                    <p class="prompt-text">"${prompt.text}"</p>
                    ${responsesHtml}
                </div>
            `;
        }
        promptHistoryBox.innerHTML = html;
    }

    // --- Command Console Logic ---
    async function executeCommand(command) {
        const response = await fetch('/api/control/command', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ command })
        });
        const result = await response.json();
        const output = response.ok ? result.response : `Error: ${result.detail}`;

        consoleOutput.textContent += `\n> ${command}\n${output.replace(/\\n/g, '\n')}`;
        consoleOutput.scrollTop = consoleOutput.scrollHeight;
    }

    // --- AGI Modal Logic ---
    function showAgiModal(agiId) {
        const agi = fullState.agis.find(a => a.id === agiId);
        if (!agi) return;

        modalAgiId.textContent = `Details for ${agi.id}`;
        modalBody.innerHTML = `
            <h4>Properties</h4>
            <p><strong>Origin Page:</strong> ${agi.origin}</p>
            <p><strong>Strength:</strong> ${agi.strength.toFixed(4)}</p>
            <div><strong>Ethics:</strong> <input type="number" id="modal-ethics-input" value="${agi.ethics.toFixed(4)}" step="0.01" min="0" max="1"></div>
            <div><strong>Strategy:</strong>
                <select id="modal-strat-select">
                    <option value="cooperative" ${agi.strat === 'cooperative' ? 'selected' : ''}>Cooperative</option>
                    <option value="disruptive" ${agi.strat === 'disruptive' ? 'selected' : ''}>Disruptive</option>
                </select>
            </div>
            <button id="modal-save-btn" data-id="${agi.id}">Save Changes</button>
            <hr style="border-color: #333; margin: 1em 0;">
            <h4>Memory Log (Last ${agi.memory.length} entries)</h4>
            <div class="scroll-box" style="height: 150px; background: #0a0a0a; padding: 0.5em; border-radius: 4px;">${agi.memory.join('<br>')}</div>
        `;
        modal.style.display = 'block';
    }

    async function saveAgiChanges(agiId) {
        const ethics = parseFloat(document.getElementById('modal-ethics-input').value);
        const strat = document.getElementById('modal-strat-select').value;

        const response = await fetch(`/api/agi/${agiId}/modify`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ethics, strat })
        });

        if (response.ok) {
            // --- FIX: Immediately update local state for instant UI feedback ---
            const agiIndex = fullState.agis.findIndex(a => a.id === agiId);
            if (agiIndex !== -1) {
                fullState.agis[agiIndex].ethics = ethics;
                fullState.agis[agiIndex].strat = strat;
                updateAgiTable(fullState.agis); // Re-render the table
            }
        }
        modal.style.display = 'none';
    }

    // --- Event Listeners ---
    const sendControl = (endpoint) => fetch(endpoint, { method: 'POST' });
    document.getElementById('start-btn').addEventListener('click', () => sendControl('/api/control/start'));
    document.getElementById('pause-btn').addEventListener('click', () => sendControl('/api/control/pause'));
    document.getElementById('step-btn').addEventListener('click', () => sendControl('/api/control/step'));
    document.getElementById('reset-btn').addEventListener('click', () => sendControl('/api/control/reset'));
    document.getElementById('apply-params-btn').addEventListener('click', () => {
        const pages = document.getElementById('pages-input').value;
        const dt = document.getElementById('dt-input').value;
        sendControl(`/api/control/params?pages=${pages}&dt=${dt}`);
    });
    document.getElementById('save-state-btn').addEventListener('click', async () => {
        const res = await fetch('/api/state/save');
        const blob = await res.blob();
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        const filename = res.headers.get('Content-Disposition')?.split('filename=')[1]?.replace(/"/g, '') || 'tt-unisim-state.json';
        a.download = filename;
        a.click();
        URL.revokeObjectURL(a.href);
    });
    document.getElementById('load-state-input').addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (!file) return;
        const formData = new FormData();
        formData.append('file', file);
        await fetch('/api/state/load', { method: 'POST', body: formData });
    });

    // Tab navigation
    document.querySelector('.tab-nav').addEventListener('click', (e) => {
        if (e.target.matches('.tab-button')) {
            document.querySelectorAll('.tab-button').forEach(b => b.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
            e.target.classList.add('active');
            document.getElementById(`tab-${e.target.dataset.tab}`).classList.add('active');
        }
    });

    // AGI Table filtering
    agiSearchInput.addEventListener('input', () => updateAgiTable(fullState.agis || []));
    agiFilterStrat.addEventListener('change', () => updateAgiTable(fullState.agis || []));

    // Command console input
    consoleInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && consoleInput.value.trim()) {
            executeCommand(consoleInput.value.trim());
            consoleInput.value = '';
        }
    });

    // --- v1.2 Training Listeners ---
    async function handleTraining(fileInputId, statusId, endpoint) {
        const fileInput = document.getElementById(fileInputId);
        const statusEl = document.getElementById(statusId);
        const file = fileInput.files[0];
        if (!file) {
            statusEl.textContent = "Please select a file first.";
            return;
        }
        statusEl.textContent = "Training in progress...";
        const formData = new FormData();
        formData.append('file', file);
        try {
            const response = await fetch(endpoint, { method: 'POST', body: formData });
            const result = await response.json();
            statusEl.textContent = response.ok ? result.status : `Error: ${result.detail}`;
        } catch (error) {
            statusEl.textContent = "An unexpected error occurred.";
        }
    }
    document.getElementById('train-image-btn').addEventListener('click', () => handleTraining('train-image-input', 'train-image-status', '/api/train/image'));
    document.getElementById('train-pdf-btn').addEventListener('click', () => handleTraining('train-pdf-input', 'train-pdf-status', '/api/train/pdf'));
    document.getElementById('train-audio-btn').addEventListener('click', () => handleTraining('train-audio-input', 'train-audio-status', '/api/train/audio'));

    promptHistoryBox.addEventListener('click', (e) => {
        const button = e.target.closest('.feedback-buttons button');
        if (!button) return;

        const container = button.parentElement;
        const vote = button.classList.contains('up') ? 'up' : 'down';

        fetch('/api/feedback', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                prompt_id: container.dataset.promptId,
                agi_id: container.dataset.agiId,
                vote: vote
            })
        }).then(res => {
            if (res.ok) {
                // --- FIX: More explicit visual feedback ---
                const responseItem = container.closest('.response-item');
                responseItem.style.transition = 'background-color 0.5s';
                responseItem.style.backgroundColor = vote === 'up' ? 'rgba(92, 184, 92, 0.2)' : 'rgba(217, 83, 79, 0.2)';
                setTimeout(() => {
                    responseItem.style.backgroundColor = 'transparent';
                }, 1000);

                const buttons = container.querySelectorAll('button');
                buttons.forEach(b => b.classList.remove('voted'));
                button.classList.add('voted');
            }
        });
    });

    // Modal listeners
    closeModalButton.addEventListener('click', () => modal.style.display = 'none');
    window.addEventListener('click', (e) => { if (e.target === modal) modal.style.display = 'none'; });
    document.addEventListener('click', (e) => {
        if (e.target.matches('.view-details-btn')) {
            showAgiModal(e.target.dataset.id);
        }
        if (e.target.matches('#modal-save-btn')) {
            saveAgiChanges(e.target.dataset.id);
        }
    });

    // --- Initial Setup ---
    initCharts();
    initNetworkGraph();
});
