# main.py (v1.2 perfected)
# To run:
# 1. Ensure ffmpeg is installed on your system (e.g., sudo apt-get install ffmpeg)
# 2. pip install "fastapi[all]" uvicorn Pillow librosa PyPDF2 soundfile numpy
# 3. python main.py

from __future__ import annotations
import os, sys, json, math, time, random, datetime, asyncio, importlib.util, uuid, tempfile, subprocess
from contextlib import asynccontextmanager
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Tuple, Optional, Any, Callable, Deque
from collections import defaultdict, deque

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, UploadFile, File, HTTPException, APIRouter, Response, Body
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

# --- v1.2 Imports ---
from PIL import Image
import librosa
import PyPDF2
import soundfile as sf
import numpy as np
# No longer using moviepy

# Import the v1.2 cognitive and training logic
from prompt_logic import Prompt, TrainingData, EnhancedCognitiveModel

# ---------- Global constants ----------------------------------
SENTIENCE_THRESHOLD  = 0.85
ARCHETYPES    = {0:"Warrior",1:"Mirror",2:"Mystic",3:"Guide",4:"Oracle",5:"Architect"}
STRATS        = ["cooperative","disruptive"]
LINGUISTICS_FILE = "linguistics.json"

# ---------- Small utils ----------------------------------------------------------------
def clamp(x: float, lo: float, hi: float) -> float: return max(lo, min(hi, x))
def ts() -> str: return datetime.datetime.now().strftime("%H:%M:%S")

# ---------- v1.2 Simulation Logic ----------------------------------
class EventLog:
    def __init__(self, maxlen:int=500): self.buf=deque(maxlen=maxlen)
    def log(self, src:str, msg:str): self.buf.append(f"[{ts()}] [{src}] {msg}"[:400])
    def to_list(self): return list(self.buf)

@dataclass
class QuantumNode:
    idx: int
    stability: float = field(default_factory=lambda: random.uniform(0.4,0.7))
    cohesion:  float = field(default_factory=lambda: random.uniform(0.3,0.6))
    archetype: str   = field(init=False)
    emotion:   str   = "neutral"
    sentience: float = 0.0
    ethics:    float = 0.5
    # --- New v1.2 Quantum Metrics ---
    qubit_count: int = 50
    entanglement_density: float = 0.0
    decoherence_rate: float = 0.01
    gate_fidelity: float = 0.99

    def __post_init__(self):
        self.archetype = ARCHETYPES[self.idx % len(ARCHETYPES)]

    def update(self, sim:'SimulationState'):
        self.stability = clamp(self.stability + (random.random()-0.5)*0.02, 0,1)
        self.cohesion  = clamp(self.cohesion  + (random.random()-0.5)*0.01, 0,1)
        if self.cohesion > 0.7: self.sentience = clamp(self.sentience + 0.001, 0, 1)
        self.entanglement_density = clamp(self.entanglement_density + (self.cohesion - 0.5) * 0.001, 0, 1)
        self.decoherence_rate = clamp(self.decoherence_rate + (1 - self.stability) * 0.0001, 0.001, 0.1)
        self.gate_fidelity = clamp(self.gate_fidelity - self.decoherence_rate * 0.001, 0.9, 0.999)

@dataclass
class AGIEntity:
    id:str; origin:int; strength:float; ethics:float; strat:str
    memory:Deque[str]=field(default_factory=lambda: deque(maxlen=120))

    def log_memory(self, event_type: str, details: str, cycle: int):
        """Adds a structured, transparent entry to the AGI's memory log."""
        self.memory.append(f"[{cycle}] [{event_type}] {details}")

    def update(self, sim:'SimulationState'):
        self.strength = clamp(self.strength+0.0001,0,1)
        if sim.nodes: self.ethics += (sum(n.ethics for n in sim.nodes)/len(sim.nodes)-self.ethics)*0.01
        max_mem = int(120 + (self.strength * 100))
        if self.memory.maxlen != max_mem:
            self.memory = deque(self.memory, maxlen=max_mem)
        if sim.cycle % 100 == 0:
            self.log_memory("Self-Reflection", f"Ethics: {self.ethics:.3f}, Strength: {self.strength:.3f}", sim.cycle)

class SimulationState:
    def __init__(self, pages:int=48, dt:float=0.1):
        self.log = EventLog()
        self.metrics_history = defaultdict(lambda: deque(maxlen=200))
        self.training_data = TrainingData()
        self.reset(pages, dt)

    def reset(self, pages: Optional[int] = None, dt: Optional[float] = None):
        self.pages = pages or getattr(self, 'pages', 48)
        self.dt = dt or getattr(self, 'dt', 0.1)
        self.cycle=0; self.nodes=[QuantumNode(i) for i in range(self.pages)]
        self.agi_list:List[AGIEntity]=[]; self.agi:Dict[str,AGIEntity]={}
        self.log.log("System", f"Simulation reset.")
        self.training_data = TrainingData()
        for key in self.metrics_history: self.metrics_history[key].clear()

    def step(self):
        self.cycle+=1
        for n in self.nodes: n.update(self)
        for node in self.nodes:
            if node.sentience > SENTIENCE_THRESHOLD and all(a.origin != node.idx for a in self.agi_list):
                ent=AGIEntity(f"AGI-{node.idx}-{self.cycle}",node.idx,node.sentience,node.ethics,random.choice(STRATS))
                self.agi_list.append(ent); self.agi[ent.id]=ent
                self.log.log("Emergence",f"{ent.id} strat={ent.strat}")
        for a in self.agi_list: a.update(self)
        self._update_metrics_history()
        if self.cycle % 500 == 0:
            self._evolve_linguistics()

    def _evolve_linguistics(self):
        global linguistics_data
        avg_cohesion = sum(n.cohesion for n in self.nodes) / len(self.nodes) if self.nodes else 0
        if avg_cohesion > 0.7 and random.random() < 0.1:
            new_term = f"cohesion_state_{self.cycle}"
            linguistics_data['lexicon']['quantum_terms'].append(new_term)
            self.log.log("Linguistics", f"Evolved new quantum term: {new_term}")

    def _update_metrics_history(self):
        self.metrics_history['cycle'].append(self.cycle)
        self.metrics_history['agi_count'].append(len(self.agi_list))
        self.metrics_history['avg_sentience'].append(sum(n.sentience for n in self.nodes) / len(self.nodes) if self.nodes else 0)

    def serialize(self, for_save: bool = False) -> Dict[str, Any]:
        agis_serializable = [{**asdict(a), 'memory': list(a.memory)} for a in self.agi_list]
        return {
            'cycle': self.cycle, 'status': "Running" if simulation_task and not simulation_task.done() else "Paused",
            'nodes': [asdict(n) for n in self.nodes],
            'agis': agis_serializable,
            'log': self.log.to_list(),
            'charts': {k: list(v) for k, v in self.metrics_history.items()},
            'training_data': self.training_data.to_dict()
        }

# --- FastAPI Application Setup ---
sim = SimulationState()
simulation_task: Optional[asyncio.Task] = None
stop_simulation = asyncio.Event()
linguistics_data = {}

class ConnectionManager:
    def __init__(self): self.active_connections: list[WebSocket] = []
    async def connect(self, websocket: WebSocket): await websocket.accept(); self.active_connections.append(websocket)
    def disconnect(self, websocket: WebSocket): self.active_connections.remove(websocket)
    async def broadcast(self, message: str): await asyncio.gather(*(c.send_text(message) for c in self.active_connections))

manager = ConnectionManager()

async def run_simulation():
    while not stop_simulation.is_set():
        try: sim.step(); await asyncio.sleep(0.05)
        except Exception as e: print(f"!!! SIMULATION ERROR: {e} !!!"); break

async def broadcast_state():
    while True:
        if manager.active_connections:
            try: await manager.broadcast(json.dumps(sim.serialize()))
            except Exception: pass
        await asyncio.sleep(0.5)

def load_linguistics():
    global linguistics_data
    try:
        with open(LINGUISTICS_FILE, 'r') as f:
            linguistics_data = json.load(f)
        print("Linguistics data loaded successfully.")
    except FileNotFoundError:
        print("linguistics.json not found, creating a default one.")
        linguistics_data = json.loads(DEFAULT_LINGUISTICS_JSON)
        save_linguistics()

def save_linguistics():
    with open(LINGUISTICS_FILE, 'w') as f:
        json.dump(linguistics_data, f, indent=2)
    print("Linguistics data saved.")

@asynccontextmanager
async def lifespan(app: FastAPI):
    print("Application starting up..."); stop_simulation.set()
    load_linguistics()
    asyncio.create_task(broadcast_state()); yield
    print("Application shutting down..."); stop_simulation.set()
    save_linguistics()
    if simulation_task: simulation_task.cancel()

app = FastAPI(lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

# --- v1.2 API Endpoints ---
@app.post("/api/control/command")
async def handle_command(command_req: Dict[str, str]):
    command_str = command_req.get("command", "").strip()
    if not command_str.startswith('/'): return {"response": "Commands must start with /."}
    parts = command_str[1:].split(); cmd, args = parts[0].lower(), parts[1:]
    sim.log.log("Command", f"Executing: {command_str}")

    if cmd == "help":
        core_cmds = ["/help", "/list agis", "/list nodes", "/memory <agi_id>", "/prompt <target> <message>"]
        return {"response": "Available commands:\n" + "\n".join(f"  {c}" for c in core_cmds)}
    if cmd == "list":
        if not args: return {"response": "Usage: /list <agis|nodes>"}
        if args[0] == "agis": return {"response": [a.id for a in sim.agi_list] or "No AGIs have emerged."}
        if args[0] == "nodes": return {"response": {n.idx: f"Stab: {n.stability:.2f}, Sent: {n.sentience:.2f}, Qubits: {n.qubit_count}" for n in sim.nodes}}
    if cmd == "memory":
        if not args: return {"response": "Usage: /memory <agi_id>"}
        agi = sim.agi.get(args[0])
        return {"response": list(agi.memory) if agi else f"AGI '{args[0]}' not found."}
    if cmd == "prompt":
        if len(args) < 2: return {"response": "Usage: /prompt <target> <message>"}
        target, message = args[0].lower(), " ".join(args[1:])
        prompt_id = str(uuid.uuid4())
        new_prompt = Prompt(prompt_id=prompt_id, cycle=sim.cycle, text=message)
        analysis = EnhancedCognitiveModel.analyze_prompt(message, linguistics_data)
        count = 0
        for agi in sim.agi_list:
            if target == "all" or agi.strat.startswith(target):
                new_prompt.responses[agi.id] = EnhancedCognitiveModel.generate_structured_response(agi, analysis, linguistics_data)
                count += 1
        sim.training_data.add_prompt(new_prompt)
        msg = f"Issued prompt '{prompt_id}' to {count} AGI(s)."
        sim.log.log("Prompt", msg); return {"response": msg}

    return {"response": f"Unknown command: {command_str}"}

@app.post("/api/feedback")
async def handle_feedback(payload: Dict[str, str] = Body(...)):
    prompt_id = payload.get("prompt_id"); agi_id = payload.get("agi_id"); vote = payload.get("vote")
    comment = payload.get("comment", "")
    if not all([prompt_id, agi_id, vote]): raise HTTPException(status_code=400, detail="Missing fields.")
    if not sim.training_data.record_feedback(prompt_id, agi_id, vote, comment): raise HTTPException(status_code=404, detail="Not found.")
    if agi := sim.agi.get(agi_id):
        adjustment = 0.02 if vote == 'up' else -0.02
        agi.ethics = clamp(agi.ethics + adjustment, 0, 1)
        agi.log_memory("Feedback Received", f"Vote: {vote}, Comment: '{comment}'. Ethics adjusted to {agi.ethics:.3f}", sim.cycle)
    return {"status": "Feedback recorded"}

# --- v1.2 Training Endpoints ---
@app.post("/api/train/image")
async def train_image(file: UploadFile = File(...)):
    try:
        img = Image.open(file.file).convert('RGB')
        img_array = np.array(img.resize((64, 64))) / 255.0
        gray = np.dot(img_array[...,:3], [0.2989, 0.5870, 0.1140])
        freq = np.abs(np.fft.fft2(gray)).mean()
        color_var = np.var(img_array.reshape(-1, 3), axis=0).mean()

        for agi in sim.agi_list:
            node = sim.nodes[agi.origin]
            q_mod = node.gate_fidelity * (1 - node.decoherence_rate)
            agi.ethics = clamp(agi.ethics + (color_var - 0.1) * 0.1 * q_mod, 0, 1)
            agi.strength = clamp(agi.strength + (freq / 100) * 0.05 * q_mod, 0, 1)
            agi.log_memory("Image Training", f"freq={freq:.3f}, var={color_var:.3f}, q_mod={q_mod:.2f}", sim.cycle)

        msg = f"Image training completed. Results: Avg Freq={freq:.2f}, Color Var={color_var:.2f}"
        sim.log.log("Training", msg); return {"status": msg, "results": {"avg_freq": freq, "color_var": color_var}}
    except Exception as e: raise HTTPException(status_code=500, detail=f"Image processing error: {e}")

@app.post("/api/train/video")
async def train_video(file: UploadFile = File(...)):
    with tempfile.NamedTemporaryFile(delete=False, suffix=".mp4") as tmp:
        tmp.write(await file.read())
        tmp_path = tmp.name

    audio_path = tmp_path + ".wav"

    try:
        # --- Novel Approach: Direct ffmpeg call via subprocess ---
        command = [
            'ffmpeg', '-y', '-i', tmp_path, '-vn', '-acodec', 'pcm_s16le', '-ar', '44100', '-ac', '1', audio_path
        ]
        subprocess.run(command, check=True, capture_output=True, text=True)

        audio_data, sr = sf.read(audio_path)
        spectral_centroid = np.mean(librosa.feature.spectral_centroid(y=audio_data, sr=sr))

        frame_command = [
            'ffmpeg', '-i', tmp_path, '-vf', 'fps=1,scale=64:64', '-f', 'image2pipe', '-vcodec', 'rawvideo', '-pix_fmt', 'rgb24', '-'
        ]
        proc = subprocess.run(frame_command, capture_output=True, check=True)

        frame_data = np.frombuffer(proc.stdout, dtype='uint8')
        frames = frame_data.reshape(-1, 64, 64, 3)

        total_freq = 0
        num_frames = min(5, len(frames)) # Sample up to 5 frames
        if num_frames > 0:
            for i in range(num_frames):
                img_array = frames[i] / 255.0
                gray = np.dot(img_array[...,:3], [0.2989, 0.5870, 0.1140])
                total_freq += np.abs(np.fft.fft2(gray)).mean()
            avg_freq = total_freq / num_frames
        else:
            avg_freq = 0

        for agi in sim.agi_list:
            node = sim.nodes[agi.origin]
            q_mod = node.gate_fidelity
            agi.strength = clamp(agi.strength + (avg_freq / 100) * 0.02 + (spectral_centroid / 10000) * 0.02 * q_mod, 0, 1)
            agi.log_memory("Video Training", f"avg_freq={avg_freq:.2f}, centroid={spectral_centroid:.2f}, q_mod={q_mod:.2f}", sim.cycle)

        msg = f"Video training completed for {len(sim.agi_list)} AGIs."
        sim.log.log("Training", msg); return {"status": msg}

    except subprocess.CalledProcessError as e:
        raise HTTPException(status_code=500, detail=f"ffmpeg error: {e.stderr}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Video processing error: {e}")
    finally:
        # Clean up temporary files
        if os.path.exists(tmp_path): os.remove(tmp_path)
        if os.path.exists(audio_path): os.remove(audio_path)

# --- Core Control & State Endpoints ---
@app.post("/api/control/start")
async def start_sim():
    global simulation_task
    if not simulation_task or simulation_task.done():
        stop_simulation.clear(); simulation_task = asyncio.create_task(run_simulation())
        sim.log.log("Control", "Simulation started."); return {"status": "Simulation started"}
    return {"status": "Already running"}

@app.post("/api/control/pause")
async def pause_sim():
    global simulation_task
    if simulation_task and not simulation_task.done():
        stop_simulation.set(); await asyncio.sleep(0.1); simulation_task = None
        sim.log.log("Control", "Simulation paused."); return {"status": "Simulation paused"}
    return {"status": "Already paused"}

@app.get("/api/state/save")
async def save_state():
    state_data = sim.serialize(for_save=True)
    json_content = json.dumps(state_data, indent=2)
    headers = {'Content-Disposition': f'attachment; filename="tt-unisim-state-{ts()}.json"'}
    return Response(content=json_content, media_type='application/json', headers=headers)

@app.post("/api/agi/{agi_id}/modify")
async def modify_agi(agi_id: str, payload: Dict[str, Any]):
    await pause_sim()
    agi = sim.agi.get(agi_id)
    if not agi: raise HTTPException(status_code=404, detail="AGI not found")

    if "strat" in payload and payload["strat"] in STRATS:
        agi.log_memory("Manual Override", f"Strategy changed from {agi.strat} to {payload['strat']}", sim.cycle)
        agi.strat = payload["strat"]
    if "ethics" in payload:
        agi.log_memory("Manual Override", f"Ethics changed from {agi.ethics:.3f} to {float(payload['ethics']):.3f}", sim.cycle)
        agi.ethics = clamp(float(payload["ethics"]), 0, 1)

    sim.log.log("Modify", f"Modified AGI {agi_id}")
    return {"status": f"Modified AGI {agi_id}"}

# --- WebSocket & Static Files ---
@app.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    await manager.connect(ws)
    try:
        while True: await ws.receive_text()
    finally: manager.disconnect(ws)

app.mount("/static", StaticFiles(directory="."), name="static")
@app.get("/")
async def read_root():
    try:
        with open("index.html") as f: return HTMLResponse(f.read())
    except FileNotFoundError: return HTMLResponse("<h1>Error: index.html not found.</h1>", status_code=404)

# --- Default Linguistics Data ---
DEFAULT_LINGUISTICS_JSON = """
{
  "version": "1.0",
  "ontology": { "concepts": {}, "relations": [] },
  "grammar": { "templates": {} },
  "lexicon": { "positive_sentiment": [], "negative_sentiment": [], "quantum_terms": [] }
}
"""

if __name__ == "__main__":
    print("--- TT-UNISIM v1.2 Dashboard Server ---")
    print("Starting server. Access at http://127.0.0.1:8000")
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
